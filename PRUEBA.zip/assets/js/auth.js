// Sesión mínima (demo)
const getSession = ()=> JSON.parse(localStorage.getItem("session")||"null");
